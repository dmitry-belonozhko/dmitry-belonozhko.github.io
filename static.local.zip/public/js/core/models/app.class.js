'use strict';

function App() {
	this.loadScript = function(args, callback) {
        if (!$('body script').hasClass('script__' + args.name)) {
            $('body').append(`<script class="script__${args.name}" src="${args.path}" defer></script>`);
        }
            callback();
	};

    this.loadScripts = function(scripts) {
        scripts.forEach(function(item, index, array) {
            if (!$('body script').hasClass('script__' + item.name)) {
                $('body').append(`<script class="script__${item.name}" src="${item.path}" defer></script>`);
            }
        });
    };

    this.setURL = function(url) {
        /* Изменение URL без перезагрузки */
          history.pushState(null, null, url);
          return true;
        /* */
    };

    this.loadPage = function(url) {
        var name = new URL(url).searchParams.get('page') || 'prime';

        if (name === 'fic') {
            var ficname = new URL(url).searchParams.get('name');
        }

        console.log(name);

    	/* Route */
    	switch(name) {
    		case 'prime':
    			app.loadScript({name: 'prime.page', path: 'js/core/views/pages/prime.page.js'}, function() {
    				page.prime({data: db, components: [{name:'common__load', path:'js/core/views/components/common__load.component.js'}, {name:'prime__content_list', path:'js/core/views/components/prime__content_list.component.js'}]});
    			});
    		break;

    		case 'about':
    			app.loadScript({name: 'about.page', path: 'js/core/views/pages/about.page.js'}, function() {
    				page.about();
    			});
    		break;

            case 'fic':
                app.loadScript({name: 'fic.page', path: 'js/core/views/pages/fic.page.js'}, function() {
                    page.fic({name: ficname, components: [{name: 'fic__content', path: 'js/core/views/components/fic__content.component.js'}]});
                });
            break;

    		default:
                app.loadScript({name: 'error404.page', path: 'js/core/views/pages/error404.page.js'}, function() {
                    page.error404();
                });
    	}
    	/* */
    };
}