'use strict';

Page.prototype.fic = function(args) {
	console.log(args);

	app.loadScripts(args.components);

	/* Загрузить необходимый файл с данными фанфика */
	app.loadScripts([
		{name: args.name, path: `/files/fics/${args.name}.js`},
		{name: 'fic__content', path: 'js/core/views/components/fic__content.component.js'}
	]);
	/* */

	console.log(fics[args.name]);

	/* Components */
	// app.loadScripts(args.components);
	/* */

    console.log('Фанфик');
	$('title').text('Фанфик');
	$('h1').text('Фанфик');
	$('.container > .content').html(component.fic__content(fics[args.name]));

	// $('.container > .content').html(component.prime__content_list(data));
};