'use strict';

Page.prototype.prime = function(args) {
	var data = args.data;

	console.log(data);

	/* Components */
	app.loadScripts(args.components);
	/* */

    console.log('Фанфики');
	$('title').text('Фанфики');
	$('h1').text('Фанфики');

	$('.container > .content').html(component.prime__content_list(data));
};