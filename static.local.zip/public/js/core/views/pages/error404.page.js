'use strict';

Page.prototype.error404 = function() {
    console.log('Error 404: Page not found!');
	$('title').text('Ошибка 404: Страница не найдена!');
	$('h1').text('Ошибка 404: Страница не найдена!');
};