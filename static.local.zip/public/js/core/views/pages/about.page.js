'use strict';

Page.prototype.about = function() {
    console.log('About');
	$('title').text('О сайте');
	$('h1').text('О сайте');
};