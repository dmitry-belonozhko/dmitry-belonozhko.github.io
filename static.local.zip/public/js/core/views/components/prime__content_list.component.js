'use strict';

Component.prototype.prime__content_list = function(request) {
	/* Содержание на главной странице */
	if (!request) {
		console.error('Ошибка: список не может быть пуст!');
	}

	/* Parse request */
	var content = '<ol>';
	for (var item of request) {
		content += `<li><button class="link" data-link="fic" data-tech="${item.tech}" data-path="${item.path}" title="${item.name}">${item.name}</button></li>`;
	}
	content += '</ol>';
	/* */

	return content;
	/* */
};