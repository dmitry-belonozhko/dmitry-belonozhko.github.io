'use strict';

Component.prototype.common__load = function() {
		var content = `
<div class="load">
	<span></span>
	<span>Загрузка&#8230;</span>
</div>
`;

		return content;
};