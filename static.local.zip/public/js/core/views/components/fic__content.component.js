'use strict';

Component.prototype.fic__content = function(data) {
		/* Content */
		var content = '';
		/* */

		/* Error */
		if (data === '404') {
			content += `<h1>Файл не найден</h1>`;
			$('title').text('Ошибка: файл не найден!');
			$('body').attr('id', 'error');
			return content;
		}
		/* */

		/* Data */
			/* Head */
		var title = data.head.title,
			direction = data.head.direction,
			rating = data.head.rating,
			body = data.body;
			/* */
		/* */

		$('title, h1').text(title);
		$('body').attr('id', 'book');

		content = `
<article>
`;

		/* Parse body */
		for (var item of data.body) {
			if (item.type === 'paragraph') {
				content += `<p>${item.data}</p>`;
			} else if (item.type === 'separator') {
				content += `<span class="separator"></span>`;
			}
		}
		/* */

		content += '</article>';

		return content;
};