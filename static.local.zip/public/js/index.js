'use strict';

/* Declare classes */
function Page() {}
function Component() {}
/* */

/* Elements */
var body = $('body'),
	content = $('.container > .content');
/* */

/* Objects */
var app = new App();
var page = new Page();
var component = new Component();
/* */

// content.html(component.list(db));

// console.log(app);

app.loadPage(location.href);

/* Button [Link] */
$('body').on('click', '.link', function() {
	var link = $(this).attr('data-link'), // /?page=fic&name=first_fic
		tech = $(this).attr('data-tech');

	app.setURL(location.origin + '?page=' + link + '&name=' + tech);
	console.log(location.origin + '?page=' + link + '&name=' + tech);
	app.loadPage(location.origin + '?page=' + link + '&name=' + tech);
});
/* */

/* Асинхронная кнопка назад */
window.onpopstate = function(event) {
	console.log(event.target.location.href);
	app.loadPage(event.target.location.href);
};
/* */