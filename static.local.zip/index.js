'use strict';

var db = [
	{
		'tech': 'first_fic',
		'name': 'First fic',
		'link': '?page=fic&name=first_fic',
		'path': '/files/fics/first_fic.js'
	},
	{
		'tech': 'second_fic',
		'name': 'Second fic',
		'link': '?page=fic&name=second_fic',
		'path': '/files/fics/second_fic.js'
	},
	{
		'tech': 'murzik_i_ko__ili_poslednij_pobeg',
		'name': 'Мурзик и ко',
		'link': '?page=fic&name=murzik_i_ko__ili_poslednij_pobeg',
		'path': '/files/fics/murzik_i_ko__ili_poslednij_pobeg.js'
	}
];