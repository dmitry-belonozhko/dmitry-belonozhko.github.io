'use strict';

if (!fics) {
	var fics = {};
}

fics = Object.assign(fics, {
	'first_fic': {
		'head': {
			'title': 'First fic',
			'direction': 'slash',
			'rating': 'G'
		},
		'body': [
			{
				'type': 'paragraph',
				'data': 'Это начало слэшового фанфика...'
			},
			{
				'type': 'separator'
			},
			{
				'type': 'paragraph',
				'data': 'Это конец слэшового фанфика после сепаратора.'
			}
		]
	}
});