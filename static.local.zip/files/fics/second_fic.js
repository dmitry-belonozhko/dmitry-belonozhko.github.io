'use strict';

if (!fics) {
	var fics = {};
}

fics = Object.assign(fics, {
	'second_fic': {
		'head': {
			'title': 'Second fic',
			'direction': 'slash',
			'rating': 'PG-13'
		},
		'body': [
			{
				'type': 'paragraph',
				'data': 'Ещё один фанфик...'
			},
			{
				'type': 'separator'
			},
			{
				'type': 'paragraph',
				'data': 'Это конец слэшового фанфика после сепаратора.'
			}
		]
	}
});